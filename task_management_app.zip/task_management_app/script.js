document.addEventListener('DOMContentLoaded', () => {
    const taskList = document.getElementById('tasks');
    const taskForm = document.getElementById('task-form');
    const taskFormElement = document.getElementById('task-form-element');
    const taskDetail = document.getElementById('task-detail');
    const addTaskBtn = document.getElementById('add-task-btn');
    const cancelBtn = document.getElementById('cancel-btn');

    let tasks = [];
    let editingTaskId = null;

    const fetchTasks = async () => {
        try {
            const response = await fetch('http://localhost:3000/tasks');
            tasks = await response.json();
            renderTasks();
        } catch (error) {
            console.error('Error fetching tasks:', error);
        }
    };

    const renderTasks = () => {
        taskList.innerHTML = '';
        tasks.forEach((task) => {
            const li = document.createElement('li');
            li.textContent = task.title;
            li.addEventListener('click', () => viewTask(task.id));
            taskList.appendChild(li);
        });
    };

    const viewTask = async (id) => {
        const response = await fetch(`http://localhost:3000/tasks/${id}`);
        const task = await response.json();
        document.getElementById('task-detail-title').textContent = task.title;
        document.getElementById('task-detail-desc').textContent = task.description;
        document.getElementById('task-detail-date').textContent = task.dueDate;
        taskDetail.classList.remove('hidden');
        taskForm.classList.add('hidden');
    };

    addTaskBtn.addEventListener('click', () => {
        taskForm.classList.remove('hidden');
        taskDetail.classList.add('hidden');
        taskFormElement.reset();
        editingTaskId = null;
    });

    cancelBtn.addEventListener('click', () => {
        taskForm.classList.add('hidden');
    });

    taskFormElement.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newTask = {
            title: document.getElementById('task-title').value,
            description: document.getElementById('task-desc').value,
            dueDate: document.getElementById('task-date').value,
        };
        if (editingTaskId !== null) {
            await fetch(`http://localhost:3000/tasks/${editingTaskId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newTask)
            });
        } else {
            await fetch('http://localhost:3000/tasks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newTask)
            });
        }
        fetchTasks();
        taskForm.classList.add('hidden');
    });

    fetchTasks();
});
